import 'package:car_x/control/admindashbord/admindashbord_controll.dart';
import 'package:car_x/view/adminview/cars_company/companys.dart';
import 'package:car_x/view/adminview/view_cars_comp/view_companys.dart';
import 'package:car_x/view/adminview/view_workshops/view_workshop.dart';
import 'package:car_x/view/adminview/workshope/workshope.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class admindashbord extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GetBuilder<admindashbordcontroller>(
        init: admindashbordcontroller(),
        builder: (controller) {
          return Scaffold(
              bottomNavigationBar: BottomNavigationBar(
                  onTap: controller.changetabindex,
                  currentIndex: controller.tabsindex,
                  unselectedItemColor: Colors.lightBlue[200],
                  selectedItemColor: Theme.of(context).primaryColorDark,
                  items: [
                    BottomNavigationBarItem(
                        icon: Icon(Icons.car_rental), label: "اضافة الشركات"),
                    BottomNavigationBarItem(
                        icon: Icon(Icons.view_list), label: "عرض الشركات"),
                    BottomNavigationBarItem(
                        icon: Icon(Icons.garage_sharp), label: "ورشات الصيانة"),
                    BottomNavigationBarItem(
                        icon: Icon(Icons.view_module),
                        label: "عرض ورشات الصيانة"),
                  ]),
              body: SafeArea(
                  child: IndexedStack(
                index: controller.tabsindex,
                children: [
                  companys(),
                  viewcompanys(),
                  workshop(),
                  viewworkshop(),
                ],
              )));
        });
  }
}
